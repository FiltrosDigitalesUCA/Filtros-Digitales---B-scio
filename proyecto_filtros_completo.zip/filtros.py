
import numpy as np
from scipy.signal import firwin, remez, butter, filtfilt, iirnotch

def filtro_fir_ventana(signal, fs, orden, fc, ventana='hamming'):
    """Filtrado FIR mediante el método de ventanas."""
    coeff = firwin(orden + 1, fc, fs=fs, window=ventana)
    return filtfilt(coeff, [1], signal)

def filtro_fir_remez(signal, fs, orden, bandas, pesos):
    """Filtrado FIR óptimo usando el algoritmo de Parks-McClellan (remez)."""
    coeff = remez(orden + 1, bandas, pesos, fs=fs)
    return filtfilt(coeff, [1], signal)

def filtro_iir(signal, fs, orden, fc, btype='low'):
    """Filtrado IIR tipo Butterworth."""
    b, a = butter(orden, fc, btype=btype, fs=fs)
    return filtfilt(b, a, signal)

def filtro_notch(signal, fs, f0=50.0, Q=30.0):
    """Filtro notch para eliminar una frecuencia específica (como 50 o 60 Hz)."""
    b, a = iirnotch(f0 / (fs / 2), Q)
    return filtfilt(b, a, signal)

def filtro_lms(signal, desired, mu=0.01, orden=32):
    """Filtro adaptativo LMS simplificado."""
    w = np.zeros(orden)
    out = np.zeros_like(signal)
    for n in range(orden, len(signal)):
        x = signal[n - orden:n]
        y = np.dot(w, x)
        e = desired[n] - y
        w += 2 * mu * e * x
        out[n] = y
    return out
